# Underground Gallery — Handoff to Claude Code

You are picking up an in-progress build of **undergroundgallery.ai**. A previous Claude session designed Stage 1B-iii and Stage 1C and packaged the code into a zip. Your job is to integrate it, then continue the build.

---

## Project context

- **Stack:** Next.js 15 (App Router) + Auth.js v5 (magic links via Resend) + Drizzle ORM + Neon Postgres + Vercel
- **Repo:** `github.com/jasonfishback/underground-gallery`
- **App lives in subfolder:** `underground-gallery/` (you should already be `cd`'d into this — confirm with `pwd`)
- **Vercel project ID:** `prj_E1Zv3KKi3udpxAoTqiarVwmgdF9o`
- **Vercel team ID:** `team_sSGerDPkWUnpnqV1oLzmIOtl`
- **Domain:** `undergroundgallery.ai` (Resend domain verified, magic links working end-to-end)
- **Sessions:** 90-day
- **Existing tables:** `users`, `accounts`, `sessions`, `verification_tokens`, `applications`

---

## What's already done

- ✅ Stage 1A: Database schema + Auth.js v5 + Resend magic links + Vercel deploy
- ✅ Stage 1B-i / 1B-ii: Auth flow working, sessions persisting

## What you're integrating now (designed, code in zip)

- **Stage 1B-iii: `/setup` page** — first-time-signin flow where new users pick:
  - **Callsign**: 3–20 chars, alphanumeric, must start with letter, profanity-filtered (`obscenity` lib), case-insensitive unique. **Set once, admin-only to change.**
  - **Region**: Google Places Autocomplete (New) — cities filter, session-tokened, **proxied through our API routes** (key stays server-side)
  - **Garage**: optional multi-vehicle list (year/make/model/trim/notes), add/remove

- **Stage 1C: Moderator approval queue**
  - Every new user lands in `pending` after `/setup`
  - Moderators designated via `MODERATOR_EMAILS` env (bootstrap) **OR** `users.is_moderator = true` (in-app promotion later)
  - Actions: approve / reject (rejection requires reason ≥3 chars, ≤500 chars, sent to user)
  - Resend emails on both transitions
  - Audit log in `moderation_events` table

## What's next after integration

- **Stage 1D**: Profile page where approved users can edit their garage (add/remove vehicles, edit notes). Callsign stays admin-only.
- **Then**: Admin tooling (change callsigns, promote/demote mods, view moderation_events history)
- **Then**: Rate-limit the Places proxy routes (per-user, e.g. 60/min via Vercel KV or Upstash)
- **Then**: Stage 2 — the actual gallery functionality (still TBD with Jason)

---

## Step-by-step integration plan

### 1. Confirm working directory

```bash
pwd
# Should end in /underground-gallery/underground-gallery
ls package.json next.config.* src/ 2>/dev/null
# Should show all three exist
```

If you're in the outer repo root, `cd underground-gallery` first.

### 2. Have Jason drop the zip in

The bundle is `ug-stage-1b-1c.zip` (20 files). Ask Jason where he saved it. Common spots: `~/Downloads/ug-stage-1b-1c.zip`. Unzip to a scratch folder first so you can review before merging:

```bash
mkdir -p /tmp/ug-stage-1b-1c
unzip ~/Downloads/ug-stage-1b-1c.zip -d /tmp/ug-stage-1b-1c
ls -R /tmp/ug-stage-1b-1c
```

### 3. Review the structure before merging

Expected file tree from the zip:

```
drizzle/
  0001_setup_profile.sql           — users columns + vehicles table
  0002_approval_queue.sql          — applications state machine + moderation_events + is_moderator

src/middleware.ts                   — gates /setup, /mod, /pending-approval

src/lib/
  validation/setup.ts               — zod + obscenity validators
  auth/require-setup.ts             — guard for approved-user pages
  auth/moderator.ts                 — env allowlist OR is_moderator flag check
  email/moderation.ts               — Resend approve/reject senders

src/db/schema.additions.ts          — Drizzle schema diff to merge into existing schema.ts

src/app/
  setup/page.tsx                    — server component, gated
  setup/actions.ts                  — completeSetup, creates pending application
  pending-approval/page.tsx         — holding page (handles both pending + rejected)
  mod/queue/page.tsx                — moderator queue
  mod/queue/actions.ts              — approve/reject server actions
  api/setup/check-callsign/route.ts — debounced availability endpoint
  api/places/autocomplete/route.ts  — Google Places proxy (cities filter)
  api/places/details/route.ts       — Google Places proxy (full details)

src/components/
  setup/SetupForm.tsx               — orchestrator
  setup/RegionPicker.tsx            — Places autocomplete with session token
  setup/GarageEditor.tsx            — multi-vehicle add/remove
  mod/ApplicationRow.tsx            — approve / reject-with-reason UI
```

### 4. Reconcile with existing files

Before copying anything in, check what's already in the repo that might collide:

```bash
ls src/middleware.ts 2>/dev/null            # existing middleware?
cat src/db/schema.ts 2>/dev/null            # existing schema — must merge by hand
ls src/auth.ts auth.ts 2>/dev/null          # confirm Auth.js export path
ls src/db/index.ts src/db.ts 2>/dev/null    # confirm db client path
```

**Things to verify and adjust before copying:**

- **Auth.js export path.** All new files import `import { auth } from "@/auth"`. Confirm this matches Jason's actual auth config location. If his is at `auth.ts` (no `src/` prefix) or `lib/auth.ts`, search-replace the import paths.
- **DB client path.** Files import `import { db } from "@/db"`. Confirm this matches.
- **Schema imports.** Files import `users`, `vehicles`, `applications`, `moderationEvents` from `@/db/schema`. Make sure the existing schema file exports these symbols after the merge.
- **Sign-in URL.** `src/middleware.ts` and the page guards redirect to `/signin`. If Jason's sign-in route is different, search-replace.
- **Existing middleware.** If `src/middleware.ts` already exists, **merge** the new matchers and logic — don't blindly overwrite.

### 5. Merge the schema additions by hand

`src/db/schema.additions.ts` is a *guide*, not a drop-in. The existing `src/db/schema.ts` already defines `users` (and likely `applications`). You need to:

- Add the new columns to the existing `users` table definition (do NOT redeclare the table)
- Add the new `vehicles` table
- Update the `applications` table definition with the new state-machine columns
- Add the new `moderationEvents` table

After merging, delete `src/db/schema.additions.ts` (it was just a reference).

### 6. Copy the rest of the files in

Once paths are reconciled, copy everything from `/tmp/ug-stage-1b-1c/` into the project, **except** `schema.additions.ts` (which you've already merged) and `middleware.ts` if it needed manual merging:

```bash
# Adjust the source path to wherever you unzipped
cp -rv /tmp/ug-stage-1b-1c/drizzle/* drizzle/
cp -rv /tmp/ug-stage-1b-1c/src/app/setup src/app/
cp -rv /tmp/ug-stage-1b-1c/src/app/pending-approval src/app/
cp -rv /tmp/ug-stage-1b-1c/src/app/mod src/app/
mkdir -p src/app/api/setup src/app/api/places
cp -rv /tmp/ug-stage-1b-1c/src/app/api/setup/* src/app/api/setup/
cp -rv /tmp/ug-stage-1b-1c/src/app/api/places/* src/app/api/places/
cp -rv /tmp/ug-stage-1b-1c/src/components/* src/components/
cp -rv /tmp/ug-stage-1b-1c/src/lib/* src/lib/
```

(Adjust paths if Jason's project doesn't use `src/`.)

### 7. Install new dependencies

```bash
npm install obscenity use-debounce zod
# resend should already be installed; verify with:
npm ls resend
```

### 8. Apply database migrations

You'll need `DATABASE_URL` in your environment (Jason has it in Vercel env; locally probably in `.env.local`):

```bash
psql "$DATABASE_URL" -f drizzle/0001_setup_profile.sql
psql "$DATABASE_URL" -f drizzle/0002_approval_queue.sql
```

Both migrations are idempotent (`IF NOT EXISTS` everywhere) — safe to rerun.

If Jason uses `drizzle-kit` to manage migrations instead of raw psql, generate proper migration files with `npx drizzle-kit generate` after merging the schema, then apply with his usual workflow. **Ask him which he prefers before running.**

### 9. Add Vercel env vars

```bash
vercel env add GOOGLE_PLACES_API_KEY      # server-side only — NO NEXT_PUBLIC_ prefix
vercel env add MODERATOR_EMAILS           # comma-separated, e.g. jason@example.com,co@example.com
vercel env add EMAIL_FROM                 # e.g. "Underground Gallery <hello@undergroundgallery.ai>"
vercel env add NEXT_PUBLIC_SITE_URL       # https://undergroundgallery.ai
```

Add to all environments (production, preview, development) so local dev works too. Pull them locally with `vercel env pull .env.local` afterward.

For `GOOGLE_PLACES_API_KEY`: Jason needs to create one in Google Cloud Console with **Places API (New)** enabled. Restrict the key to "None" application restriction (since it's server-side only) and "Places API (New)" API restriction.

### 10. Verify everything compiles

```bash
npm run build
# OR if there's no build script set up:
npx tsc --noEmit
npx next lint
```

Fix any path-resolution errors that come from the import-path differences flagged in step 4.

### 11. Smoke test locally

```bash
npm run dev
```

Then in the browser:

1. Sign in as a brand-new user (use a fresh email, magic link from Resend)
2. Should auto-redirect to `/setup`
3. Try a callsign with a leading digit ("7eleven") — should fail with "must start with a letter"
4. Try a profane callsign — should fail with "Pick a different callsign"
5. Pick a valid callsign, region, optionally add a vehicle, submit
6. Should redirect to `/pending-approval`
7. Add yourself to `MODERATOR_EMAILS` env var, restart dev server
8. Visit `/mod/queue` — should see your own pending application
9. Approve it — should get an email, then `/` should be accessible

### 12. Commit and push

Use a feature branch, not `main`:

```bash
git checkout -b stage-1b-iii-and-1c
git add .
git status                    # review what's staged
git diff --cached --stat      # quick overview
git commit -m "Stage 1B-iii: /setup page + Stage 1C: mod approval queue

- New users complete profile setup (callsign, region, garage)
- Pending applications go to mod queue
- Approve/reject with email notifications via Resend
- Adds vehicles, moderation_events tables; extends users + applications

Migrations: 0001_setup_profile.sql, 0002_approval_queue.sql
New env vars: GOOGLE_PLACES_API_KEY, MODERATOR_EMAILS, EMAIL_FROM, NEXT_PUBLIC_SITE_URL"
git push -u origin stage-1b-iii-and-1c
```

Then open a PR on GitHub for Jason to review before merging to `main`.

---

## Things that were verified in the prior Claude session

- TypeScript: full project typechecks clean against a realistic Drizzle (neon-http) client
- Validators (zod + obscenity): 7/7 callsign cases pass, 7/7 moderation action cases pass
- Profanity filter catches common slurs and leetspeak via `obscenity`'s English dataset
- Race condition on callsign uniqueness handled by partial unique index on `lower(callsign)` plus a friendly pre-check error before the DB constraint fires
- Google Places API: confirmed using **Autocomplete (New)** at `places.googleapis.com/v1/places:autocomplete` with `includedPrimaryTypes: ["(cities)"]` and session tokens for billing efficiency

## Decisions Jason already made (don't re-litigate these)

- Callsign rules: strict (3–20 alphanumeric, must start with letter, profanity filter)
- Callsign change policy: **admin-only** after initial setup
- Region field: Google Places autocomplete (cities)
- Places API key: **proxied** through our API routes (server-side key)
- Garage at setup: **optional** (can finish setup with empty garage, add later)
- Approval flow: every new user goes to queue, no auto-approve
- Mod designation: env allowlist (`MODERATOR_EMAILS`) for bootstrap + `users.is_moderator` flag for in-app promotion later
- Mod actions: approve / reject only (no "request more info" or "ban" yet)
- User notifications: email on both approve and reject

## Use Outlook for any email tasks

Jason uses Outlook only — never suggest or offer Gmail alternatives.

---

## Once integrated and merged

Tell Jason:
- "Stage 1B-iii and 1C are merged. Ready for Stage 1D — profile page where users edit their garage. Want me to start that, or something else first?"

If he says yes to 1D, things to clarify before writing code:
- Should users be able to mark a different vehicle as primary, or is the first-added always primary?
- Soft-delete vehicles (keep history) or hard delete?
- Any per-vehicle photo upload at this stage, or text-only for 1D?
